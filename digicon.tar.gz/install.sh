#!/bin/sh

# install dependencies
sudo -E apt-get install pip
sudo -E apt-get install python-qt4
sudo -E apt-get python install scipy
sudo -E apt-get update