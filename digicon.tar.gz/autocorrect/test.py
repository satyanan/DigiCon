from __init__ import correctPage

print correctPage(['paracetamol has lap', 'cold fever headache'], [1, 0])