Load the classifier using:

import pickle as pkl

mlp = pkl.load(open('classifier.bin', 'rb'))
